import { motion } from 'motion/react';
import { HandHeart, Award, Sparkles, Target } from 'lucide-react';

const values = [
  { icon: HandHeart, title: 'Respeto', description: 'Valoramos a cada persona y al entorno' },
  { icon: Award, title: 'Liderazgo', description: 'Formamos líderes con iniciativa' },
  { icon: Sparkles, title: 'Empatía', description: 'Nos ponemos en el lugar del otro' },
  { icon: Target, title: 'Compromiso', description: 'Cumplimos nuestras promesas' }
];

export default function Values() {
  return (
    <section id="valores" className="py-20 bg-[#1E5631] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1"/>
          </pattern>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-white mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 2.5rem)', fontWeight: '700' }}>
            Valores Scout
          </h2>
          <p className="text-[#F4EBD0] max-w-2xl mx-auto" style={{ fontSize: '1.125rem' }}>
            Formamos líderes con valores sólidos que marcarán la diferencia en su comunidad
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <motion.div
              key={value.title}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <motion.div
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: 'spring', stiffness: 300 }}
                className="w-20 h-20 mx-auto mb-4 bg-[#DAA520] rounded-full flex items-center justify-center shadow-lg"
              >
                <value.icon className="w-10 h-10 text-white" />
              </motion.div>
              <h3 className="text-white mb-2" style={{ fontSize: '1.5rem' }}>
                {value.title}
              </h3>
              <p className="text-[#F4EBD0]/80">
                {value.description}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <div className="inline-block bg-white/10 backdrop-blur-sm rounded-2xl p-8 max-w-3xl">
            <p className="text-white" style={{ fontSize: '1.125rem', lineHeight: '1.8' }}>
              En Scouts VII Monterrey, cada actividad está diseñada para fortalecer el carácter, 
              desarrollar habilidades para la vida y cultivar un sentido profundo de responsabilidad 
              hacia sí mismos y su comunidad.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
