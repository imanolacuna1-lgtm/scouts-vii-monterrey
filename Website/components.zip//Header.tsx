import { useState, useEffect } from 'react';
import { Menu, X, TreePine } from 'lucide-react';
import { Button } from './ui/button';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md' : 'bg-white/95 backdrop-blur-sm'
    }`}>
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollToSection('inicio')}>
            <div className="flex items-center justify-center w-12 h-12 bg-[#1E5631] rounded-full">
              <TreePine className="w-7 h-7 text-[#DAA520]" />
            </div>
            <div>
              <div className="text-[#1E5631]" style={{ fontSize: '1.25rem', fontWeight: '700', lineHeight: '1.2' }}>
                Scouts VII
              </div>
              <div className="text-[#1E5631]/70" style={{ fontSize: '0.875rem' }}>
                Monterrey
              </div>
            </div>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection('inicio')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors">
              Inicio
            </button>
            <button onClick={() => scrollToSection('actividades')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors">
              Actividades
            </button>
            <button onClick={() => scrollToSection('valores')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors">
              Valores
            </button>
            <button onClick={() => scrollToSection('ubicacion')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors">
              Ubicación
            </button>
            <Button 
              onClick={() => scrollToSection('inscripcion')}
              className="bg-[#DAA520] hover:bg-[#DAA520]/90 text-white rounded-full px-6"
            >
              Inscribir a mi hijo
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-[#1E5631]"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 flex flex-col gap-4">
            <button onClick={() => scrollToSection('inicio')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors text-left">
              Inicio
            </button>
            <button onClick={() => scrollToSection('actividades')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors text-left">
              Actividades
            </button>
            <button onClick={() => scrollToSection('valores')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors text-left">
              Valores
            </button>
            <button onClick={() => scrollToSection('ubicacion')} className="text-[#1E5631] hover:text-[#DAA520] transition-colors text-left">
              Ubicación
            </button>
            <Button 
              onClick={() => scrollToSection('inscripcion')}
              className="bg-[#DAA520] hover:bg-[#DAA520]/90 text-white rounded-full"
            >
              Inscribir a mi hijo
            </Button>
          </div>
        )}
      </nav>
    </header>
  );
}
