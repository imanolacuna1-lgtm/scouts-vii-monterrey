import { motion } from 'motion/react';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

const images = [
  {
    src: 'https://images.unsplash.com/photo-1698731036724-518ca5c61739?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY291dHMlMjBjaGlsZHJlbiUyMGNhbXBpbmd8ZW58MXx8fHwxNzYxNzg2NjcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    alt: 'Campamento scout'
  },
  {
    src: 'https://images.unsplash.com/photo-1758272960205-96258d60ac1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1wZmlyZSUyMGNvbW11bml0eXxlbnwxfHx8fDE3NjE3ODY2NzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    alt: 'Fogata comunitaria'
  },
  {
    src: 'https://images.unsplash.com/photo-1652245341837-44fe516f01d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraWRzJTIwaGlraW5nJTIwZm9yZXN0fGVufDF8fHx8MTc2MTc4NjY3NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    alt: 'Excursión al bosque'
  },
  {
    src: 'https://images.unsplash.com/photo-1761406362713-3075480956ec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraWRzJTIwb3V0ZG9vciUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NjE3ODY2NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    alt: 'Aventura al aire libre'
  }
];

export default function Gallery() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-[#1E5631] mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 2.5rem)', fontWeight: '700' }}>
            Momentos Inolvidables
          </h2>
          <p className="text-[#1E5631]/70 max-w-2xl mx-auto" style={{ fontSize: '1.125rem' }}>
            Capturamos las sonrisas, el aprendizaje y la aventura en cada actividad
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="overflow-hidden border-none shadow-lg hover:shadow-2xl transition-all duration-300 group">
                <div className="relative h-72 overflow-hidden">
                  <ImageWithFallback
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-[#1E5631]/0 group-hover:bg-[#1E5631]/20 transition-all duration-300" />
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <div className="inline-flex items-center gap-2 bg-[#F4EBD0] px-6 py-3 rounded-full">
            <div className="w-3 h-3 bg-[#DAA520] rounded-full animate-pulse" />
            <span className="text-[#1E5631]" style={{ fontSize: '1rem', fontWeight: '500' }}>
              Más de 150 niños han vivido la experiencia scout
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
