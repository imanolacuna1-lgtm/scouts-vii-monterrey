import { motion } from 'motion/react';
import { Instagram, Facebook } from 'lucide-react';

export default function SocialMedia() {
  const socialLinks = [
    {
      name: 'Instagram',
      icon: Instagram,
      url: 'https://www.instagram.com/scoutsviimonterrey',
      color: 'from-purple-500 to-pink-500',
      handle: '@scoutsviimonterrey'
    },
    {
      name: 'TikTok',
      icon: ({ className }: { className?: string }) => (
        <svg
          className={className}
          viewBox="0 0 24 24"
          fill="currentColor"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
        </svg>
      ),
      url: 'https://www.tiktok.com/@scoutsviimonterrey',
      color: 'from-black to-gray-800',
      handle: '@scoutsviimonterrey'
    },
    {
      name: 'Facebook',
      icon: Facebook,
      url: 'https://www.facebook.com/scoutsviimonterrey',
      color: 'from-blue-600 to-blue-700',
      handle: 'Scouts VII Monterrey'
    }
  ];

  return (
    <section id="redes" className="py-20 bg-gradient-to-b from-white to-[#F4EBD0]/20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-[#1E5631] mb-4">
            Síguenos en Redes Sociales
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Mantente al día con nuestras actividades, eventos y aventuras. 
            Únete a nuestra comunidad en línea y vive la experiencia scout cada día.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {socialLinks.map((social, index) => (
            <motion.a
              key={social.name}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="group relative bg-white rounded-2xl shadow-lg p-8 overflow-hidden transition-all duration-300 hover:shadow-2xl"
            >
              {/* Gradient background on hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${social.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
              
              {/* Content */}
              <div className="relative z-10 flex flex-col items-center text-center space-y-4">
                {/* Icon */}
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${social.color} flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-300`}>
                  <social.icon className="w-8 h-8 text-white" />
                </div>
                
                {/* Name */}
                <h3 className="text-[#1E5631]">
                  {social.name}
                </h3>
                
                {/* Handle */}
                <p className="text-gray-600">
                  {social.handle}
                </p>
                
                {/* CTA */}
                <div className="pt-2">
                  <span className={`inline-block px-6 py-2 rounded-full bg-gradient-to-r ${social.color} text-white group-hover:shadow-lg transition-shadow duration-300`}>
                    Seguir
                  </span>
                </div>
              </div>

              {/* Decorative element */}
              <div className="absolute -bottom-6 -right-6 w-24 h-24 rounded-full bg-[#DAA520] opacity-5 group-hover:opacity-10 transition-opacity duration-300" />
            </motion.a>
          ))}
        </div>

        {/* Additional CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <p className="text-gray-600">
            Comparte tus experiencias scout con el hashtag{' '}
            <span className="text-[#1E5631]">#ScoutsVIIMonterrey</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
