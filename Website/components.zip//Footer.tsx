import { TreePine, Instagram, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#1E5631] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Logo y descripción */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-[#DAA520] rounded-full flex items-center justify-center">
                <TreePine className="w-7 h-7 text-white" />
              </div>
              <div>
                <div style={{ fontSize: '1.25rem', fontWeight: '700' }}>Scouts VII</div>
                <div style={{ fontSize: '0.875rem' }} className="text-[#F4EBD0]/80">Monterrey</div>
              </div>
            </div>
            <p className="text-[#F4EBD0]/80" style={{ fontSize: '0.875rem' }}>
              Formando líderes con valores desde 1995. Una comunidad que enseña amistad, aventura y servicio.
            </p>
          </div>

          {/* Contacto */}
          <div>
            <h3 className="mb-4" style={{ fontSize: '1.125rem', fontWeight: '600' }}>Contacto</h3>
            <div className="space-y-2 text-[#F4EBD0]/80" style={{ fontSize: '0.875rem' }}>
              <p>
                <a href="mailto:info@scoutsvii.mx" className="hover:text-[#DAA520] transition-colors">
                  info@scoutsvii.mx
                </a>
              </p>
              <p>San Pedro de Pinta</p>
              <p>Monterrey, Nuevo León</p>
            </div>
          </div>

          {/* Redes sociales */}
          <div>
            <h3 className="mb-4" style={{ fontSize: '1.125rem', fontWeight: '600' }}>Síguenos</h3>
            <div className="flex gap-4">
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/10 hover:bg-[#DAA520] rounded-full flex items-center justify-center transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/10 hover:bg-[#DAA520] rounded-full flex items-center justify-center transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a 
                href="https://tiktok.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/10 hover:bg-[#DAA520] rounded-full flex items-center justify-center transition-colors"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 text-center text-[#F4EBD0]/60" style={{ fontSize: '0.875rem' }}>
          <p>© 2025 Scouts VII Monterrey. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
