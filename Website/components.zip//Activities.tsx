import { motion } from 'motion/react';
import { Tent, Users, Heart } from 'lucide-react';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

const activities = [
  {
    icon: Tent,
    title: 'Aventura y Campamentos',
    emoji: '🌲',
    description: 'Vive experiencias inolvidables en la naturaleza, aprende supervivencia y desarrolla independencia.',
    image: 'https://images.unsplash.com/photo-1761406362713-3075480956ec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraWRzJTIwb3V0ZG9vciUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NjE3ODY2NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    icon: Users,
    title: 'Trabajo en Equipo',
    emoji: '🤝',
    description: 'Fortalece habilidades sociales, aprende a colaborar y construye amistades duraderas.',
    image: 'https://images.unsplash.com/photo-1611476655709-3e79fc3b91fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMHRlYW13b3JrJTIwbmF0dXJlfGVufDF8fHx8MTc2MTc4NjY3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    icon: Heart,
    title: 'Servicio a la Comunidad',
    emoji: '💛',
    description: 'Desarrolla empatía y responsabilidad social ayudando a quienes más lo necesitan.',
    image: 'https://images.unsplash.com/photo-1643214410415-de1976ad74ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMGhlbHBpbmclMjBjb21tdW5pdHl8ZW58MXx8fHwxNzYxNzg2Njc0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

export default function Activities() {
  return (
    <section id="actividades" className="py-20 bg-gradient-to-b from-white to-[#F4EBD0]/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-[#1E5631] mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 2.5rem)', fontWeight: '700' }}>
            Nuestras Actividades
          </h2>
          <p className="text-[#1E5631]/70 max-w-2xl mx-auto" style={{ fontSize: '1.125rem' }}>
            Cada encuentro es una oportunidad para crecer, aprender y crear recuerdos inolvidables
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {activities.map((activity, index) => (
            <motion.div
              key={activity.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
            >
              <Card className="overflow-hidden hover:shadow-xl transition-shadow duration-300 border-none bg-white h-full">
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={activity.image}
                    alt={activity.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1E5631]/60 to-transparent" />
                  <div className="absolute bottom-4 left-4 flex items-center gap-2">
                    <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center">
                      <activity.icon className="w-6 h-6 text-[#1E5631]" />
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-[#1E5631] mb-3 flex items-center gap-2" style={{ fontSize: '1.5rem' }}>
                    {activity.title} <span>{activity.emoji}</span>
                  </h3>
                  <p className="text-[#1E5631]/70">
                    {activity.description}
                  </p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
