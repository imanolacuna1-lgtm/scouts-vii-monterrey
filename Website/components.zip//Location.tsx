import { motion } from 'motion/react';
import { MapPin, Navigation } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

export default function Location() {
  const openGoogleMaps = () => {
    window.open('https://www.google.com/maps/search/Black+Bear+Park+San+Pedro+Monterrey', '_blank');
  };

  return (
    <section id="ubicacion" className="py-20 bg-[#1E5631]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-white mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 2.5rem)', fontWeight: '700' }}>
            Nuestra Ubicación
          </h2>
          <p className="text-[#F4EBD0] max-w-2xl mx-auto" style={{ fontSize: '1.125rem' }}>
            Nos reunimos en Black Bear Park, un espacio ideal para actividades al aire libre
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Card className="p-8 bg-white border-none shadow-xl">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 bg-[#DAA520] rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-[#1E5631] mb-2" style={{ fontSize: '1.5rem' }}>
                    Black Bear Park
                  </h3>
                  <p className="text-[#1E5631]/70">
                    San Pedro, Monterrey, Nuevo León
                  </p>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div className="flex items-center gap-3 text-[#1E5631]/70">
                  <div className="w-2 h-2 bg-[#DAA520] rounded-full" />
                  <span>Amplio espacio al aire libre</span>
                </div>
                <div className="flex items-center gap-3 text-[#1E5631]/70">
                  <div className="w-2 h-2 bg-[#DAA520] rounded-full" />
                  <span>Áreas para campamentos y fogatas</span>
                </div>
                <div className="flex items-center gap-3 text-[#1E5631]/70">
                  <div className="w-2 h-2 bg-[#DAA520] rounded-full" />
                  <span>Instalaciones seguras</span>
                </div>
              </div>

              <Button 
                onClick={openGoogleMaps}
                className="w-full bg-[#1E5631] hover:bg-[#1E5631]/90 text-white rounded-lg flex items-center justify-center gap-2"
              >
                <Navigation className="w-5 h-5" />
                Ver en Google Maps
              </Button>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <Card className="overflow-hidden border-none shadow-xl">
              <div className="relative h-96 bg-[#F4EBD0]/20">
                {/* Map placeholder - se puede integrar con Google Maps API */}
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3596.2074939823775!2d-100.36897!3d25.686613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8662be77c1d66f31%3A0x7f3d0f75d6e1e2a6!2sBlack%20Bear%20Park%2C%20San%20Pedro%20Garza%20Garc%C3%ADa%2C%20N.L.!5e0!3m2!1ses!2smx!4v1234567890"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Mapa de ubicación"
                  className="grayscale-[30%]"
                />
                <div className="absolute inset-0 bg-[#1E5631]/10 pointer-events-none" />
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
