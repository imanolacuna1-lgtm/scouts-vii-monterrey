import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X } from 'lucide-react';

export default function WhatsAppButton() {
  const [showTooltip, setShowTooltip] = useState(false);

  const handleClick = () => {
    // Número de WhatsApp - reemplazar con el número real
    const phoneNumber = '5218112345678';
    const message = encodeURIComponent('¡Hola! Me gustaría obtener más información sobre Scouts VII Monterrey.');
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {showTooltip && (
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
            className="absolute bottom-full right-0 mb-2 bg-white rounded-lg shadow-lg p-3 whitespace-nowrap"
          >
            <p className="text-[#1E5631]" style={{ fontSize: '0.875rem' }}>
              ¿Necesitas ayuda? ¡Escríbenos!
            </p>
            <div className="absolute bottom-0 right-6 transform translate-y-1/2 rotate-45 w-2 h-2 bg-white" />
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={handleClick}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="w-14 h-14 bg-[#25D366] hover:bg-[#20BA5A] rounded-full shadow-lg flex items-center justify-center text-white transition-colors"
        style={{ boxShadow: '0 4px 12px rgba(37, 211, 102, 0.4)' }}
      >
        <MessageCircle className="w-7 h-7" />
      </motion.button>

      <motion.div
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute inset-0 bg-[#25D366] rounded-full opacity-20 pointer-events-none"
      />
    </div>
  );
}
