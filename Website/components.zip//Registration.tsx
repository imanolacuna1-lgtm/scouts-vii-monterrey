import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { CheckCircle2, Send, AlertCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export default function Registration() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    parentName: '',
    childName: '',
    childAge: '',
    email: '',
    phone: ''
  });

  // IMPORTANTE: Reemplaza esta URL con tu URL de Google Apps Script
  // Instrucciones en el comentario más abajo
  const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwuzx7Q6FclIQyv-giYJTHpTjGmWDNaEDR87hO5F9_1GA34dqSagt_ShZSsF_uKNvHb/exec';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      // Preparar los datos para enviar
      const dataToSend = {
        ...formData,
        timestamp: new Date().toLocaleString('es-MX', { timeZone: 'America/Monterrey' })
      };

      // Enviar a Google Sheets
      const response = await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors', // Necesario para Google Apps Script
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataToSend)
      });

      // Con mode: 'no-cors' no podemos leer la respuesta, pero si no hay error, asumimos éxito
      setIsSubmitted(true);
      toast.success('¡Inscripción enviada exitosamente!');
      
      // Resetear el formulario después de 5 segundos
      setTimeout(() => {
        setIsSubmitted(false);
        setFormData({ parentName: '', childName: '', childAge: '', email: '', phone: '' });
      }, 5000);

    } catch (err) {
      console.error('Error al enviar formulario:', err);
      setError('Hubo un error al enviar tu inscripción. Por favor intenta nuevamente.');
      toast.error('Error al enviar la inscripción');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="inscripcion" className="py-20 bg-gradient-to-b from-[#F4EBD0]/30 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-[#1E5631] mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 2.5rem)', fontWeight: '700' }}>
            ¡Únete hoy al movimiento Scout!
          </h2>
          <p className="text-[#1E5631]/70 max-w-2xl mx-auto" style={{ fontSize: '1.125rem' }}>
            Regístrate para recibir información o asistir a una demostración gratuita. 
            ¡Descubre por qué las familias confían en nosotros!
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-2xl mx-auto"
        >
          <Card className="p-8 shadow-2xl border-none bg-white">
            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3"
                  >
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <p className="text-red-800" style={{ fontSize: '0.875rem' }}>{error}</p>
                  </motion.div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="parentName">Nombre del padre/madre/tutor *</Label>
                  <Input
                    id="parentName"
                    name="parentName"
                    type="text"
                    required
                    value={formData.parentName}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="border-[#1E5631]/20 focus:border-[#DAA520] rounded-lg"
                    placeholder="Ej: María González"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="childName">Nombre del niño/a *</Label>
                  <Input
                    id="childName"
                    name="childName"
                    type="text"
                    required
                    value={formData.childName}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="border-[#1E5631]/20 focus:border-[#DAA520] rounded-lg"
                    placeholder="Ej: Juan González"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="childAge">Edad del niño/a *</Label>
                  <Input
                    id="childAge"
                    name="childAge"
                    type="number"
                    required
                    min="6"
                    max="18"
                    value={formData.childAge}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="border-[#1E5631]/20 focus:border-[#DAA520] rounded-lg"
                    placeholder="Ej: 10"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Correo electrónico *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="border-[#1E5631]/20 focus:border-[#DAA520] rounded-lg"
                    placeholder="correo@ejemplo.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Teléfono *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="border-[#1E5631]/20 focus:border-[#DAA520] rounded-lg"
                    placeholder="(81) 1234-5678"
                  />
                </div>

                <Button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-[#DAA520] hover:bg-[#DAA520]/90 text-white rounded-lg py-6 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  style={{ fontSize: '1.125rem' }}
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Enviar inscripción
                    </>
                  )}
                </Button>

                <p className="text-center text-[#1E5631]/60" style={{ fontSize: '0.875rem' }}>
                  * Campos obligatorios. Tus datos están protegidos y solo se usarán para contactarte.
                </p>
              </form>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="text-center py-8"
              >
                <CheckCircle2 className="w-20 h-20 text-[#DAA520] mx-auto mb-4" />
                <h3 className="text-[#1E5631] mb-3" style={{ fontSize: '1.75rem', fontWeight: '700' }}>
                  ¡Gracias por tu interés!
                </h3>
                <p className="text-[#1E5631]/70" style={{ fontSize: '1.125rem' }}>
                  Hemos recibido tu información. Nos pondremos en contacto contigo muy pronto 
                  para darte más detalles sobre nuestras actividades.
                </p>
                <div className="mt-6 text-[#DAA520]" style={{ fontSize: '3rem' }}>
                  🎉
                </div>
              </motion.div>
            )}
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
